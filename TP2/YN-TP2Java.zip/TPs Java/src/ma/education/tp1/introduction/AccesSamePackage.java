package ma.education.tp1.introduction;

public class AccesSamePackage {
		
	public static void main(String[] args) {
		Salle s1 = new Salle(1,"Salle A") ;
		System.out.println(s1.id+" , "+ s1.nom);

	}

}
