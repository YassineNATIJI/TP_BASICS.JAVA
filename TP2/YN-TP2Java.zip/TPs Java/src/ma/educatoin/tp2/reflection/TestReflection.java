package ma.educatoin.tp2.reflection;

public class TestReflection {

	public static void main(String[] args) {
		
	}

}
